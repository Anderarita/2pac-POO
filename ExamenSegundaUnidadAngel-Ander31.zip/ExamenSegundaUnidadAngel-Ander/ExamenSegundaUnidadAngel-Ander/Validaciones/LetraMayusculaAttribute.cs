﻿using System.ComponentModel.DataAnnotations;

namespace ExamenSegundaUnidadAngel_Ander.Validaciones
{
    public class LetraMayusculaAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null || string.IsNullOrEmpty(value.ToString())) 
            {
                return ValidationResult.Success;
            }

            var Letra = value.ToString()[0].ToString();

            if (Letra != Letra.ToUpper()) 
            {
                return new ValidationResult("La primera letra debe ser mayuscula");
            }
            return ValidationResult.Success;
        }
    }
}