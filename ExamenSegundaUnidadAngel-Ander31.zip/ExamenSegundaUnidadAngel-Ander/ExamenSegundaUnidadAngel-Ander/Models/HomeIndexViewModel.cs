﻿namespace ExamenSegundaUnidadAngel_Ander.Models
{
    public class HomeIndexViewModel
    {
        public IEnumerable<Registro> registros { get; set; }
    }
}
