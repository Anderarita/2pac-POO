﻿using ExamenSegundaUnidadAngel_Ander.Validaciones;
using System.ComponentModel.DataAnnotations;

namespace ExamenSegundaUnidadAngel_Ander.Models
{
    public class CorreoElectronico : IValidatableObject
    {
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [LetraMayuscula]

        public string Nombre { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Nombre != null && Nombre.Length > 0)
            {
                var Letra = Nombre.ToString()[0].ToString();

                if(Letra != Letra.ToUpper()) 
                {
                    yield return new ValidationResult("La primera letra del nombre debe ser mayuscula",
                        new[] { nameof(Nombre)});
                }
            }
        }
        [Display(Name = "Correo Electronico")]
        [Required(ErrorMessage = "El {0} es obligatorio")]
        [EmailAddress(ErrorMessage = "El {0} debe ser un correo valido")]
        public string Email { get; set; }
    }
}
