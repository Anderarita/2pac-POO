﻿using System.ComponentModel.DataAnnotations;

namespace ExamenSegundaUnidadAngel_Ander.Models
{
    public class Registro
    {
        [Required(ErrorMessage = "El nombre es obligatorio")]
        public string Nombre { get; set; }
        [Display(Name = "Correo Electronico")]
        [Required(ErrorMessage = "El {0} es obligatorio")]
        [EmailAddress(ErrorMessage = "El {0} debe ser un correo valido")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p1 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p2 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p3 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p4 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p5 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p6 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p7 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p8 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p9 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p10 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p11 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p12 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p13 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p14 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p15 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p16 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p17 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p18 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p19 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p20 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p21 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p22 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p23 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p24 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p25 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p26 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p27 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p28 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p29 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p30 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p31 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p32 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p33 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p34 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p35 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p36 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p37 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p38 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p39 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p40 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p41 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p42 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p43 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p44 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p45 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p46 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p47 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p48 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p49 { get; set; }
        [Required(ErrorMessage = "Seleccione una Opcion")]
        public string p50 { get; set; }
    }
}
