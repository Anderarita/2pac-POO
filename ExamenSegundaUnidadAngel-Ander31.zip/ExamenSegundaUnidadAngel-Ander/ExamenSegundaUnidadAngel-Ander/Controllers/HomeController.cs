﻿using ExamenSegundaUnidadAngel_Ander.Models;
using ExamenSegundaUnidadAngel_Ander.Servicios;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ExamenSegundaUnidadAngel_Ander.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IservicioEmail serviciosEmail;
        private readonly IConfiguration configuration;

        public HomeController(ILogger<HomeController> logger,
            IservicioEmail serviciosEmail,
            IConfiguration configuration)
        {
            _logger = logger;
            this.serviciosEmail = serviciosEmail;
            this.configuration = configuration;
        }

        public IActionResult Index()
        {
            var numeroElementos = configuration.GetValue<int>("card-elemnts");
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult FormularioTest() 
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> FormularioTest(Registro modelo)
        {
            _logger.LogInformation("Nombre: " + modelo.Email);
            await serviciosEmail.Enviar(modelo);
            return RedirectToAction("Gracias");
        }

        public IActionResult Gracias()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}