﻿using ExamenSegundaUnidadAngel_Ander.Models;
using MailKit.Net.Smtp;
using MimeKit;

namespace ExamenSegundaUnidadAngel_Ander.Servicios
{
    public class ServicioMailTrap: IservicioEmail
    {
        public async Task Enviar(Registro modelo)
        {
            var email = new MimeMessage();
            email.From.Add(new MailboxAddress(modelo.Nombre, modelo.Email));
            email.To.Add(new MailboxAddress("Jose Angel", "angelnataren16@gmail.com"));

            email.Subject = $"Contacto de: {modelo.Nombre}";
            email.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = $"<p>{modelo.p1}," +
                $"{modelo.p2}," +
                $",{modelo.p3}" +
                $",{modelo.p4}" +
                $",{modelo.p5}" +
                $",{modelo.p6}" +
                $",{modelo.p7}" +
                $",{modelo.p8}" +
                $",{modelo.p9}" +
                $",{modelo.p10}</p>"
            };

            using (var smtp = new SmtpClient()) 
            {
                smtp.Connect("sandbox.smtp.mailtrap.io", 587, false);
                smtp.Authenticate("b3b627d7f5d0ea", "9049b6a74b75ca");

                await smtp.SendAsync(email);
                await smtp.DisconnectAsync(true);
            }
        }
    }
}
