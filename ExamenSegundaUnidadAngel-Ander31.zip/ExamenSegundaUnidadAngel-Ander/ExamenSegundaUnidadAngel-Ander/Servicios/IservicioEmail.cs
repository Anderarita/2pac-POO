﻿using ExamenSegundaUnidadAngel_Ander.Models;

namespace ExamenSegundaUnidadAngel_Ander.Servicios
{
    public interface IservicioEmail
    {
        Task Enviar(Registro modelo);
    }
}